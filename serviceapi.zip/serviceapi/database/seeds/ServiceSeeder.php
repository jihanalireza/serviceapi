<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ServiceSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('service')->insert([
        	'nisn' => "6432900123",
        	'nama' => "Gania Alianda",
        	'kelas' => "12 RPL A",
        	'jurusan' => "RPL",
        ]);
    }
}
