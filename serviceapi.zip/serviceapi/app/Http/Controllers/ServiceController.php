<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Service;
use App\Transformers\ServiceTransformer;


class ServiceController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Service $service)
    {
        $service = $service->all();
        return fractal($service,new ServiceTransformer())->respond(200);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request, Service $service)
    {
        $this->validate($request,[
            'nisn' => 'required|unique:service,nisn',
            'nama' => 'required',
            'kelas' => 'required',
            'jurusan' => 'required',
        ]);

        $service = $service->create([
            'nisn' => $request->nisn,
            'nama' => $request->nama,
            'kelas' => $request->kelas,
            'jurusan' => $request->jurusan
        ]);
        $result = fractal($service,new ServiceTransformer())->respond(201);
        
        return $result;
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
     $getService = Service::find($id);
     $result = fractal($getService,new ServiceTransformer())->respond();
     return $result;
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request , $id)
    {
        $this->validate($request,[
            'nisn' => 'required|unique:service,nisn,'.$id,
            'nama' => 'required',
            'kelas' => 'required',
            'jurusan' => 'required',
        ]);

        $service = Service::find($id);
        $service->nisn = $request->nisn;
        $service->nama = $request->nama;
        $service->kelas = $request->kelas;
        $service->jurusan = $request->jurusan;
        $service->save();

        $result = fractal($service,new ServiceTransformer())->respond(201);
        return $result;
        
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $delete = Service::destroy($id);
        return response()->json([
            "message" => "Deleted Success",
        ]);
    }
}
