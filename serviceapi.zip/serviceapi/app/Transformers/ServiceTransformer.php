<?php

namespace App\Transformers;

use App\Service;
use League\Fractal\TransformerAbstract;

class ServiceTransformer extends TransformerAbstract
{
    /**
     * A Fractal transformer.
     *
     * @return array
     */
    public function transform(Service $service)
    {
        return [
            "id" => $service->id,
            "nisn" => $service->nisn,
            "nama" => $service->nama,
            "kelas" => $service->kelas,
            "jurusan" => $service->jurusan,
            "created_at" => $service->created_at,
        ];
    }
}
